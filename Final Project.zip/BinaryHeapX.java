package familyTree;

import java.util.ArrayList;
import java.util.List;
import java.util.Scanner;

/**
* Implements a binary heap.
* Note that all "matching" is based on the compareTo method.
* Based off BinaryHeap.java by Mark Allen Weiss. Edits that I made will be denoted by "Justin"
* @author Mark Allen Weiss. Reworked by Justin Tang with some help from Jielei "Tiffany" Li
*/

//replace occurrence of "AnyType"  with "employee" within the insert, percolateDown method in BinaryHeap2.java
//public class BinaryHeap2<AnyType extends Comparable<? super AnyType>>
public class BinaryHeapX<AnyType> {
	 public void printTree( )
	 {
			int rowLength = 1;
			int rowPosition = 0;
	
			for(int i = 1; i <= currentSize; i++) {
				//System.out.print(array[i] + " ");
				array[i].printRec();
				rowPosition++;
				if (rowPosition == rowLength) {
					System.out.println();
					rowLength *= 2;
					rowPosition = 0;
				}
			}
	 }

	 public void printArray( )
	 {
		    
			for(int i = 1; i <= currentSize; i++)
				//System.out.print(array[i] + " ");
				array[i].printRec();
			System.out.println();

	 }

/**
* Construct the binary heap.
*/
public BinaryHeapX( )
{
  this( DEFAULT_CAPACITY );
}

/**
* Construct the binary heap.
* @param capacity the capacity of the binary heap.
*/
public BinaryHeapX( int capacity )
{
  currentSize = 0;
  array = new Employee[ capacity + 1 ];
}

/**
* Construct the binary heap given an array of items.
*/
public BinaryHeapX( Employee [ ] items )
{
      currentSize = items.length;
      array = (Employee[]) new Comparable[ ( currentSize + 2 ) * 11 / 10 ];

      int i = 1;
      for( Employee item : items )
          array[ i++ ] = item;
      buildHeap( );
}

/**
* Insert into the priority queue, maintaining heap order.
* Duplicates are allowed.
* @param x the item to insert.
*/
public void insert( Employee x )
{
  if( currentSize == array.length - 1 )
      enlargeArray( array.length * 2 + 1 );

      // Percolate up
  int hole = ++currentSize;
  for( array[ 0 ] = x; x.compareTo( array[ hole / 2 ] ) < 0; hole /= 2 )
      array[ hole ] = array[ hole / 2 ];
  array[ hole ] = x;
}


private void enlargeArray( int newSize )
{
      Employee [] old = array;
      //array = (employee []) new Comparable[ newSize ];
      Employee [] array = new Employee[newSize];
      for( int i = 0; i < old.length; i++ )
          array[ i ] = old[ i ];        
}

/**
* Find the smallest item in the priority queue.
* @return the smallest item, or throw an UnderflowException if empty.
*/
public Employee findMin( )
{
//  if( isEmpty( ) )
//      throw new UnderflowException( );
  return array[ 1 ];
}

/**
* Remove the smallest item from the priority queue.
* @return the smallest item, or throw an UnderflowException if empty.
*/
public Employee deleteMin( )
{
//     if( isEmpty( ) )
//         throw new UnderflowException( );

  Employee minItem = findMin( );
  array[ 1 ] = array[ currentSize-- ];
  percolateDown( 1 );

  return minItem;
}

/**
* Establish heap order property from an arbitrary
* arrangement of items. Runs in linear time.
*/
private void buildHeap( )
{
  for( int i = currentSize / 2; i > 0; i-- )
      percolateDown( i );
}

/**
* Test if the priority queue is logically empty.
* @return true if empty, false otherwise.
*/
public boolean isEmpty( )
{
  return currentSize == 0;
}

/**
* Make the priority queue logically empty.
*/
public void makeEmpty( )
{
  currentSize = 0;
}

private static final int DEFAULT_CAPACITY = 100;//This is the capacity of the array. I made it bigger so it could store more items - Justin
private int currentSize;      // Number of elements in heap
private Employee [ ] array; // The heap array

/**
* Internal method to percolate down in the heap.
* @param hole the index at which the percolate begins.
*/
private void percolateDown( int hole )
{
  int child;
  Employee tmp = array[ hole ];

  for( ; hole * 2 <= currentSize; hole = child )
  {
      child = hole * 2;
      if( child != currentSize &&
              array[ child + 1 ].compareTo( array[ child ] ) < 0 )
          child++;
      if( array[ child ].compareTo( tmp ) < 0 )
          array[ hole ] = array[ child ];
      else
          break;
  }
  array[ hole ] = tmp;
}

public void sortedArray(){
	
}

/**
 * This is a brand new method that I wrote to get some UI into the program - Justin 
 */

/*
public void programOptions(){
	Scanner scn = new Scanner(System.in);
	System.out.println("Would you like to do anything else?");
	String option = scn.nextLine();
	
	if (option == "Yes"){
			Scanner scc = new Scanner(System.in);
			System.out.println("Options: Enter 1 to add another employee \n"
					+ "Enter 2 to edit an employee's information \n"
					+ "Enter 3 to remove an employee");
			String editOption = scc.nextLine();
			if (editOption == "1"){
				System.out.println("This is where we add in another employee with their info");
			}else if (editOption == "2"){
				System.out.println("This is where we edit an employee's information");
			}else if (editOption == "3"){
				System.out.println("Here, we can remove an employee from the tree if they resign or get terminated");
			}
	}else if (option == "No"){
		System.out.print("Derp");
	}
}
*/

//Test program

/*public static void main( String [ ] args )
{
int numItems = 10000;
//adding in preliminary entries into D
String[] name = {"Kevin Malone", "Angela Martin", "Michael Scott", "Jim Halpert", "Dwight Schrute", "Pam Beasley", "Creed Bratton", "Ryan Howard", "Kelly Kapoor", "Phyllis Vance", "Stanley Hudson", "Oscar Martinez", "Toby Flenderson"};
String[] company = {"Dunder Mifflin Paper Company","Dunder Mifflin Paper Company","Dunder Mifflin Paper Company","Dunder Mifflin Paper Company","Dunder Mifflin Paper Company","Dunder Mifflin Paper Company", "Dunder Mifflin Paper Company", "Dunder Mifflin Paper Company", "Dunder Mifflin Paper Company","Dunder Mifflin Paper Company", "Dunder Mifflin Paper Company","Dunder Mifflin Paper Company","Dunder Mifflin Paper Company"};
String[] position = {"Accountant", "Accountant", "Regional Manager", "Sales Rep", "Assistant to the Regional Manager", "Receptionist", "Quality Assurance Director", "Temp", "Customer Service Rep", "Sales Rep", "Sales Rep", "Accountant", "Human Resources Rep"};
int[] salary = {60000, 80000, 120000, 50000, 70000, 30000, 100000, 20000, 35000, 75000, 70000, 70000, 55000};
int[] XP = {5, 8, 15, 4, 10, 4, 20, 1, 3, 12, 9, 6, 5};


	BinaryHeapX<Employee> h = new BinaryHeapX();
	
	for(int i = 0; i < name.length; i++){
	    Employee buffer = new Employee(name[i], company[i], position[i], XP[i], salary[i]);
		h.insert(buffer);
	}

	List<Employee> temps = new ArrayList<Employee>();
	
	System.out.println("Sort on salary:\n");
	
	
	for (int i = 0; i < name.length; i++){
		//Employee b =h.findMin(); b.printRec();
		//h.deleteMin();
		h.printArray(); 
	}
	
}*/
}
