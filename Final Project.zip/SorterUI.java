package familyTree;




import java.util.*;
import java.io.*;

/**
 * This is the user interface. 
 * @author Justin Tang. Additional help from Jielei "Tiffany" Li
 *
 */

public class SorterUI {

	//Test program
	public static void main( String [ ] args ) throws IOException
	{
	int numItems = 10000;
	//adding in preliminary entries into D
	String[] name = {"Kevin Malone", "Angela Martin", "Michael Scott", "Jim Halpert", "Dwight Schrute", "Pam Beasley", "Creed Bratton", "Ryan Howard", "Kelly Kapoor", "Phyllis Vance", "Stanley Hudson", "Oscar Martinez", "Toby Flenderson"};
	String[] company = {"Dunder Mifflin Paper Company","Dunder Mifflin Paper Company","Dunder Mifflin Paper Company","Dunder Mifflin Paper Company","Dunder Mifflin Paper Company","Dunder Mifflin Paper Company", "Dunder Mifflin Paper Company", "Dunder Mifflin Paper Company", "Dunder Mifflin Paper Company","Dunder Mifflin Paper Company", "Dunder Mifflin Paper Company","Dunder Mifflin Paper Company","Dunder Mifflin Paper Company"};
	String[] position = {"Accountant", "Accountant", "Regional Manager", "Sales Rep", "Assistant to the Regional Manager", "Receptionist", "Quality Assurance Director", "Temp", "Customer Service Rep", "Sales Rep", "Sales Rep", "Accountant", "Human Resources Rep"};
	int[] salary = {60000, 80000, 120000, 50000, 70000, 30000, 100000, 20000, 35000, 75000, 70000, 70000, 55000};
	int[] XP = {5, 8, 15, 4, 10, 4, 20, 1, 3, 12, 9, 6, 5};


		BinaryHeapX<Employee> h = new BinaryHeapX();
		
		for(int i = 0; i < name.length; i++){
		    Employee buffer = new Employee(name[i], company[i], position[i], XP[i], salary[i]);
			h.insert(buffer);
		}

		List<Employee> temps = new ArrayList<Employee>();
		
		System.out.println("Sort on salary:\n");
		
		//Employee b =h.findMin(); b.printRec();
		//System.out.println("");
		//h.printArray();
		
		//setting up the scanners to open up the files
		Scanner inFile1 = new Scanner(new File("empNames.txt"));
		Scanner inFile2 = new Scanner(new File("empComps.txt"));
		Scanner inFile3 = new Scanner(new File("empPosition.txt"));
		Scanner inFile4 = new Scanner(new File("empSalary.txt"));
		Scanner inFile5 = new Scanner(new File("empXP.txt"));
		
		
		BufferedWriter bw1 = null;
		FileWriter fw1 = null;
		BufferedWriter bw2 = null;
		FileWriter fw2 = null;
		BufferedWriter bw3 = null;
		FileWriter fw3 = null;
		BufferedWriter bw4 = null;
		FileWriter fw4 = null;
		BufferedWriter bw5 = null;
		FileWriter fw5 = null;
		
		bw1 = new BufferedWriter(new FileWriter("empNames.txt"));
		bw2 = new BufferedWriter(new FileWriter("empComps.txt"));
		bw3 = new BufferedWriter(new FileWriter("empPosition.txt"));
		bw4 = new BufferedWriter(new FileWriter("empSalary.txt"));
		bw5 = new BufferedWriter(new FileWriter("empXP.txt"));
		
		for (int i = 0; i < name.length; i++){
			Employee c =h.findMin(); c.printRec();
			bw1.write(c.name + " ");
			bw2.write(c.company + " ");
			bw3.write(c.position + " ");
			bw4.write(Integer.toString(c.salary) + " ");
			bw5.write(Integer.toString(c.salary) + " ");
			
			
			h.deleteMin();
		}
		
		if (bw1 != null)
			bw1.close();
		if (fw1 != null)
			fw1.close();
		if (bw2 != null)
			bw2.close();
		if (fw2 != null)
			fw2.close();
		if (bw3 != null)
			bw3.close();
		if (fw3 != null)
			fw3.close();
		if (bw4 != null)
			bw4.close();
		if (fw4 != null)
			fw4.close();
		if (bw5 != null)
			bw5.close();
		if (fw5 != null)
			fw5.close();
		
		

		
		
		
		/*
		for (int i = 0; i < name.length; i++){
			//Employee b =h.findMin(); b.printRec();
			//h.deleteMin();
			h.printArray(); 
		}*/
		
	}
	
}
