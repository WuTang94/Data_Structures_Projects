package familyTree;

//Author Justin Tang
public class Employee {
	
	public String name;
	public String company;
	public String position;
	public int XP;
	public int salary;
	
	public Employee(String name, String company, String position, int XP, int salary){
		this.name = name; this.company = company; this.position = position; this.XP = XP; this.salary = salary;
	}
	
	//this method helps with sorting
	public int compareTo(Employee entry){
		int i = 0;
		
		if (this.salary > entry.salary)
			i = 1;
		if (this.salary < entry.salary)
			i = -1;
		if (this.salary == entry.salary)
			i = 0;
		return (i);
	}
	
	public void printRec(){
		System.out.println("Name: " + this.name + "\nCompany: " + this.company + "\nPosition: " + this.position + "\nExperience: " + this.XP + "\nSalary: " + this.salary);
	}

}
